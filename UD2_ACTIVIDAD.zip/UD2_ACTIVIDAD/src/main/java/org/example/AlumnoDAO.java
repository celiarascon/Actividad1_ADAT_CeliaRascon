package org.example;

import java.sql.*;
public class AlumnoDAO {
    private Connection connection;

    public AlumnoDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean insertarAlumno(Alumno alumno) {
        try {
            // Verificar si el alumno ya existe (según el DNI)
            if (!existeAlumno(alumno.getDni())) {
                String query = "INSERT INTO alumnos (id, nombre, apellido, dni, curso) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement st = connection.prepareStatement(query);
                st.setInt(1, alumno.getId());
                st.setString(2, alumno.getNombre());
                st.setString(3, alumno.getApellido());
                st.setString(4, alumno.getDni());
                st.setString(5, alumno.getCurso());

                st.executeUpdate();
                System.out.println("Alumno insertado: " + alumno.getNombre() + " " + alumno.getApellido());
                return true;
            } else {
                System.out.println("Alumno con DNI " + alumno.getDni() + " ya existe.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error al insertar el alumno: " + e.getMessage());
            return false;
        }
    }


    public boolean existeAlumno(String dni) {
        try {
            String query = "SELECT 1 FROM alumnos WHERE dni = ?";
            PreparedStatement st = connection.prepareStatement(query);
            st.setString(1, dni);
            ResultSet resultSet = st.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            System.err.println("Error al verificar existencia de alumno: " + e.getMessage());
            return false;
        }
    }
}

