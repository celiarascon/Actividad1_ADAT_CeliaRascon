package org.example;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        DBConnection dbConnection = new DBConnection();
        Connection conn = dbConnection.connect();

        if (conn != null) {
            List<Alumno> alumnos = parsearAlumnosXML("src/main/java/org/example/alumnos.xml");
            System.out.println("Alumnos leídos del XML: " + alumnos.size());
            AlumnoDAO alumnoDAO = new AlumnoDAO(conn);
            int alumnosInsertados = 0;
            for (Alumno alumno : alumnos) {
                if (alumnoDAO.insertarAlumno(alumno)) {
                    alumnosInsertados++;
                }
            }

            System.out.println("Cantidad de alumnos insertados: " + alumnosInsertados);
        } else {
            System.out.println("No se pudo establecer la conexión.");
        }
    }

    public static List<Alumno> parsearAlumnosXML(String archivoXML) {
        List<Alumno> alumnos = new ArrayList<>();
        try {
            File archivo = new File(archivoXML);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(archivo);

            doc.getDocumentElement().normalize();
            NodeList listaAlumnos = doc.getElementsByTagName("alumno");

            for (int i = 0; i < listaAlumnos.getLength(); i++) {
                Node nodo = listaAlumnos.item(i);
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) nodo;
                    int id = Integer.parseInt(elemento.getElementsByTagName("id").item(0).getTextContent());
                    String nombre = elemento.getElementsByTagName("nombre").item(0).getTextContent();
                    String apellido = elemento.getElementsByTagName("apellido").item(0).getTextContent();
                    String dni = elemento.getElementsByTagName("dni").item(0).getTextContent();
                    String curso = elemento.getElementsByTagName("curso").item(0).getTextContent();

                    Alumno alumno = new Alumno(id, nombre, apellido, dni, curso);
                    alumnos.add(alumno);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al parsear el archivo XML: " + e.getMessage());
        }
        return alumnos;
    }
}
