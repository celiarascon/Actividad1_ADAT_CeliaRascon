package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/escuela";
    private static final String USER = "postgres";
    private static final String PASSWORD = "Hospital2014*";

    public Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos.");
            crearTablaSiNoExiste(conn);
        } catch (SQLException e) {
            System.err.println("Error en la conexión a la base de datos.");
        }
        return conn;
    }

    private void crearTablaSiNoExiste(Connection connection) {
        String crearTablaSQL = "CREATE TABLE IF NOT EXISTS alumnos (" +
                "id INT PRIMARY KEY, " +
                "nombre VARCHAR(50), " +
                "apellido VARCHAR(50), " +
                "dni VARCHAR(10) UNIQUE, " +
                "curso VARCHAR(10))";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(crearTablaSQL);
            System.out.println("Tabla 'alumnos' verificada/existe.");
        } catch (SQLException e) {
            System.err.println("Error al verificar o crear la tabla 'alumnos'.");
        }
    }
}
